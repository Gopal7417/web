package com.potix.task1;

import java.util.List;
import java.sql.*;
import javax.sql.*;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;

public class TaskDAOImpl implements TaskDAO {
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcTemplate jdbcTemplate;
	protected DataFieldMaxValueIncrementer taskIncer;
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void setJdbcTemplate(JdbcTemplate  jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setTaskIncer(DataFieldMaxValueIncrementer taskIncer) {
		this.taskIncer = taskIncer;
	}

	public Task insert(Task t) throws Exception {

		String sql = "INSERT INTO tasks VALUES(?, ?)";
		Object[] params = new Object[] { t.getTitle(), t.getDescription() };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR};
		jdbcTemplate.update(sql, params,types);
		
		return t;
	}

	public Task update(Task t) throws Exception {
		String sql = "UPDATE tasks SET title = ?, description = ? WHERE id = ?";
		Object[] params = new Object[] { t.getTitle(), t.getDescription(), t.getId() };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.INTEGER};
		jdbcTemplate.update(sql, params, types);
		
		return t;
	}

	public void delete(Task t) throws Exception {
		String sql = "DELETE FROM tasks WHERE id = ?";
		Object[] params = new Object[] { t.getId() };
		int types[] = new int[] { Types.INTEGER};
		jdbcTemplate.update(sql, params, types);
	}

	protected class TaskMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			Task t = new Task();
			t.setId(rs.getInt("id"));
			t.setTitle(rs.getString("title"));
			t.setDescription(rs.getString("description"));
			
			return t;
		}
	}
	public Task findById(int id) throws Exception {
		String sql = "SELECT * FROM tasks WHERE id = ?";
		Object[] params = new Object[] { id };
		int types[] = new int[] { Types.INTEGER};
		
		List ts = jdbcTemplate.query(sql, params, types, new TaskMapper());
		if (ts.isEmpty())
			return null;
		return (Task)ts.get(0); 
	}

	public List findAll() throws Exception {
		String sql = "SELECT * FROM tasks";
		return jdbcTemplate.query(sql, new TaskMapper());
	}
	
	public void call() {
System.out.println("1st enter");
		String sql = "INSERT INTO tasks VALUES(?, ?)";
		String ee = "hello";
		String e2 = "gopal";
		System.out.println("enter");
		Object[] params = new Object[] {ee, e2 };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR};
		jdbcTemplate.update(sql, params,types);
		
		System.out.println("Leave");
	}
}
